package com.cg.mob.ctrl;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.mob.dto.Mobile;
import com.cg.mob.dto.PurchaseDetails;
import com.cg.mob.service.IMobileService;


@Controller
@RequestMapping("/mobile")
public class MobileController {
	
	
	@Autowired
	private IMobileService mobSer;
	
	
	
	public IMobileService getMobSer() {
		return mobSer;
	}



	public void setMobSer(IMobileService mobSer) {
		this.mobSer = mobSer;
	}

	
	
	public Model setDataInModel(int mId, Model m){
		
		System.out.println("Mobile id is "+mId);
		
		Mobile mob = mobSer.getMobileById(mId);
		System.out.println(mob);
		
		
		List<Integer> idList = mobSer.getAllMobileIds();
		System.out.println(idList);
	
		m.addAttribute("mList",idList);
		m.addAttribute("mobDetails",mob);
		m.addAttribute("purchaseDetails",new PurchaseDetails());
		
		return m;
	}
	
	
	@RequestMapping("/book")
	public String prepareBooking(@RequestParam("mobId") int mobId,Model m){
		
		m = setDataInModel(mobId, m);
		
	return "pages/MobileBook";
	}
	
	@RequestMapping("/addMobile")
	public String addMobileDetails(@RequestParam("mobId") int mId,@ModelAttribute("purchaseDetails")@Valid PurchaseDetails pDetail,BindingResult result,Model m){
	
		
		if(result.hasErrors()){
			System.out.println("in error function");
			m = setDataInModel(mId, m);
			return "pages/MobileBook";
		}
		
		else
		{
			System.out.println("Comming Mobile Id"+mId);
			
			System.out.println("in insert part" + pDetail);
			
			Mobile mob = mobSer.getMobileById(mId);
			System.out.println(mob);
			pDetail.setTotalAmt((pDetail.getBookedQuan() * mob.getPrice()));
			
			//update quantity
			mobSer.updateMobileQuantity(pDetail.getBookedQuan(),mob.getMobileId());
			
			
			
			//Add Purchase Details
			pDetail = mobSer.addPurchaseDetails(pDetail);
			
			System.out.println("After  "+pDetail);	

			
			m.addAttribute("mobileDetails",mob);
			m.addAttribute("purDetails",pDetail);
			
			
			return "pages/SuccessPage";
		}
			
	}
	
}
